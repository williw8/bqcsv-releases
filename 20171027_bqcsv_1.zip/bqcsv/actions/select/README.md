# select
A bqcsv action module that allows selection of columns from a CSV file. 
