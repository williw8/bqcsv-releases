# csvdb
Python library to manipulate comma separated value (CSV) files.  
See the wiki for examples.
