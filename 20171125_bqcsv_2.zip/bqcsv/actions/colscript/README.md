# colscript
A bqcsv action module that applies a python script to all of the row elements of the specified column or columns. 
