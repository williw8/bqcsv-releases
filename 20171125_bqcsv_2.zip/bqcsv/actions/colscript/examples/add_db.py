

def updateHeaders(old_headers):
  return ['New Column']
 
def updateColumn(old_values): 
  return ["Default Value"]
