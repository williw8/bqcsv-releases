
def updateHeaders(old_headers):
  return list() 
 
def updateColumns(old_values): 
  return list() 
