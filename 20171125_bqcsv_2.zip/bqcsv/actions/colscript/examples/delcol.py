
def updateHeaders(old_headers):
  return list() 
 
def updateColumn(old_values): 
  return list() 
